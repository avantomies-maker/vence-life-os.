const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
const DS = '49f357f3-f889-46a5-be1d-542b4536826f';
const LIB = '4b1222ad-9cda-4ba5-b381-5c552b1702a1';
const fields = ['Take Vitamins','Back Roller','Back Workout','Stretching','Leg Day','Core / Abs','Chest Workout'];
const weekdays = ['Rest Day','Back Workout','Stretching','Leg Day','Core / Abs','Chest Workout','Rest Day'];
function reply(obj, status=200){return new Response(JSON.stringify(obj),{status,headers});}
async function notion(env,path,method='GET',body){
  if(!env.NOTION_TOKEN) throw new Error('NOTION_TOKEN secret is missing');
  const r=await fetch('https://api.notion.com/v1/'+path,{method,headers:{Authorization:'Bearer '+env.NOTION_TOKEN,'Notion-Version':'2022-06-28','Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const j=await r.json(); if(!r.ok)throw new Error('Notion '+r.status+': '+(j.message||'API error'));return j;
}
function plain(p){return (p?.title||[]).map(x=>x.plain_text).join('');}
function dateLocal(d=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Helsinki',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);}
function logObj(p){const x=p.properties||{};return {id:p.id,date:x.Date?.date?.start||'',checks:Object.fromEntries(fields.map(f=>[f,!!x[f]?.checkbox]))};}
async function queryAll(env,id,filter){let all=[],cursor;do{const r=await notion(env,'databases/'+id+'/query','POST',{page_size:100,...(filter?{filter}:{}),...(cursor?{start_cursor:cursor}:{})});all.push(...r.results);cursor=r.has_more?r.next_cursor:null;}while(cursor&&all.length<1500);return all;}
export async function onRequest({request,env}){
  try{
    if(request.method==='GET'){
      const [logs,habits]=await Promise.all([queryAll(env,DS),queryAll(env,LIB)]);
      return reply({today:dateLocal(),logs:logs.map(logObj),habits:habits.map(p=>({name:plain(p.properties?.Name),type:p.properties?.Type?.select?.name,day:p.properties?.Day?.select?.name,duration:p.properties?.['Duration (min)']?.number||0,active:p.properties?.Active?.checkbox!==false})).filter(x=>x.name&&x.active)});
    }
    if(request.method==='POST'){
      const b=await request.json();const date=String(b.date||'');const field=String(b.field||'');
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!fields.includes(field)||typeof b.checked!=='boolean')return reply({error:'Invalid input'},400);
      if(date!==dateLocal())return reply({error:'Only today can be edited'},400);
      const found=await queryAll(env,DS,{property:'Date',date:{equals:date}});
      let p;
      if(found.length){p=await notion(env,'pages/'+found[0].id,'PATCH',{properties:{[field]:{checkbox:b.checked}}});}
      else {p=await notion(env,'pages','POST',{parent:{database_id:DS},properties:{Name:{title:[{text:{content:date}}]},Date:{date:{start:date}},[field]:{checkbox:b.checked}}});}
      return reply({ok:true,log:logObj(p)});
    }
    return reply({error:'Method not allowed'},405);
  }catch(e){return reply({error:e.message||'Unknown error'},500);}
}
